﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.DTO
{
    public class RespuestaDTO<T>
    {
        public List<string> Errores { get; set; }
        public string Mensaje { get; set; }
        public HttpStatusCode CodigoStatus { get; set; }
        public T Data { get; set; }
    }
}
