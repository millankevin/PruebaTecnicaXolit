﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.DTO
{
    public class TransaccionDTO
    {
        public int idTransaccion { get; set; }
        public int fkIdCuenta { get; set; }
        public int fkIdTipoTransaccion { get; set; }
        public string cuentaDestino { get; set; }
        public string comentario { get; set; }
        public float valor { get; set; }
        public bool estado { get; set; }
    }
}
