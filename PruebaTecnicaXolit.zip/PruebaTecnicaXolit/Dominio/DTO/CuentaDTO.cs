﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.DTO
{
    public class CuentaDTO
    {
        public int idCuenta { get; set; }
        public int fkIdCliente { get; set; }
        public string numeroCuenta { get; set; }
        public float saldo { get; set; }
        public bool estado { get; set; }
    }
}
