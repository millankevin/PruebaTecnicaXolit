﻿namespace Dominio.DTO
{
    public class ClienteDTO
    {
        public int idCliente { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string identificacion { get; set; }
        public string correoElectronico { get; set; }
        public string telefono { get; set; }
        public bool estado { get; set; }
        public int idTipoCliente { get; set; }
    }
}
