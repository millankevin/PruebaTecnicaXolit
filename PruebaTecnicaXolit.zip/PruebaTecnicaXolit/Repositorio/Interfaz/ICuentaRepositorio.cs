﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio.Interfaz
{
    public interface ICuentaRepositorio
    {
        Task<IEnumerable<CuentaDTO>> ObtenerCuenta();
        Task<int> CrearCuenta(CuentaDTO Cuenta);
        Task<int> ActualizarCuenta(CuentaDTO Cuenta);
        Task<int> EliminarCuenta(CuentaDTO Cuenta);
    }
}
