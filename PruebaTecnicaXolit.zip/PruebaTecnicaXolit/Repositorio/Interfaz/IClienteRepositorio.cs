﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio.Interfaz
{
    public interface IClienteRepositorio
    {
        Task<IEnumerable<ClienteDTO>> ObtenerCliente();
        Task<int> CrearCliente(ClienteDTO Cliente);
        Task<int> ActualizarCliente(ClienteDTO Cliente);
        Task<int> EliminarCliente(ClienteDTO Cliente);
    }
}
