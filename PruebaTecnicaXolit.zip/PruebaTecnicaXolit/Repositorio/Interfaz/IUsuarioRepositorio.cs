﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio.Interfaz
{
    public interface IUsuarioRepositorio
    {
        Task<IEnumerable<UsuarioDTO>> ObtenerUsuario();
        Task<int> CrearUsuario(UsuarioDTO Usuario);
        Task<int> ActualizarUsuario(UsuarioDTO Usuario);
        Task<int> EliminarUsuario(UsuarioDTO Usuario);
    }
}
