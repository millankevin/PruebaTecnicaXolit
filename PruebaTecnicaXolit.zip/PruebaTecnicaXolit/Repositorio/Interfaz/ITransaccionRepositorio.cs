﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio.Interfaz
{
    public interface ITransaccionRepositorio
    {
        Task<IEnumerable<TransaccionDTO>> ObtenerTransaccion();
        Task<int> CrearTransaccion(TransaccionDTO Transaccion);
        Task<int> ActualizarTransaccion(TransaccionDTO Transaccion);
        Task<int> EliminarTransaccion(TransaccionDTO Transaccion);
    }
}
