﻿using Dapper;
using Dominio.DTO;
using Repositorio.Interfaz;
using System.Data.SqlClient;

namespace Repositorio.Implementacion
{
    public class TransaccionRepositorio : Repositorio<TransaccionDTO>, ITransaccionRepositorio
    {
        public TransaccionRepositorio(string connectionString) : base(connectionString)
        {
        }
        public async Task<IEnumerable<TransaccionDTO>> ObtenerTransaccion()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryAsync<TransaccionDTO>("sp_obtener_transaccion",
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> CrearTransaccion(TransaccionDTO Transaccion)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@fk_id_cuenta", Transaccion.fkIdCuenta);
            parametros.Add("@fk_id_tipo_transaccion", Transaccion.fkIdTipoTransaccion);
            parametros.Add("@cuenta_destino", Transaccion.cuentaDestino);
            parametros.Add("@comentario", Transaccion.comentario);
            parametros.Add("@valor", Transaccion.valor);
            parametros.Add("@estado", Transaccion.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_crear_transaccion", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> ActualizarTransaccion(TransaccionDTO Transaccion)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_transaccion", Transaccion.idTransaccion);
            parametros.Add("@fk_id_cuenta", Transaccion.fkIdCuenta);
            parametros.Add("@fk_id_tipo_transaccion", Transaccion.fkIdTipoTransaccion);
            parametros.Add("@cuenta_destino", Transaccion.cuentaDestino);
            parametros.Add("@comentario", Transaccion.comentario);
            parametros.Add("@valor", Transaccion.valor);
            parametros.Add("@estado", Transaccion.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_actualizar_transaccion", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> EliminarTransaccion(TransaccionDTO Transaccion)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_transaccion", Transaccion.idTransaccion);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_eliminar_transaccion", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }
    }
}
