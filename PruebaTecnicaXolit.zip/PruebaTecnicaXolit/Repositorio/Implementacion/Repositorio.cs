﻿using Dapper.Contrib.Extensions;
using Repositorio.Interfaz;

namespace Repositorio.Implementacion
{
    public class Repositorio<T> : IRepositorio<T> where T : class
    {
        protected string _connectionString;

        public Repositorio(string connectionString)
        {
            SqlMapperExtensions.TableNameMapper = (type) => { return $"{type.Name}"; };
            _connectionString = connectionString;
        }
    }
}
