﻿using Dapper;
using Dominio.DTO;
using Repositorio.Interfaz;
using System.Data.SqlClient;

namespace Repositorio.Implementacion
{
    public class CuentaRepositorio : Repositorio<CuentaDTO>, ICuentaRepositorio
    {
        public CuentaRepositorio(string connectionString) : base(connectionString)
        {
        }
        public async Task<IEnumerable<CuentaDTO>> ObtenerCuenta()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryAsync<CuentaDTO>("sp_obtener_Cuenta",
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> CrearCuenta(CuentaDTO Cuenta)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@fk_id_cliente", Cuenta.fkIdCliente);
            parametros.Add("@numero_cuenta", Cuenta.numeroCuenta);
            parametros.Add("@saldo", Cuenta.saldo);
            parametros.Add("@estado", Cuenta.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_crear_Cuenta", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> ActualizarCuenta(CuentaDTO Cuenta)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_cuenta", Cuenta.idCuenta);
            parametros.Add("@fk_id_cliente", Cuenta.fkIdCliente);
            parametros.Add("@numero_cuenta", Cuenta.numeroCuenta);
            parametros.Add("@saldo", Cuenta.saldo);
            parametros.Add("@estado", Cuenta.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_actualizar_Cuenta", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> EliminarCuenta(CuentaDTO Cuenta)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_cuenta", Cuenta.idCuenta);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_eliminar_Cuenta", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }
    }
}
