﻿using Dapper;
using Dominio.DTO;
using Repositorio.Interfaz;
using System.Data.SqlClient;

namespace Repositorio.Implementacion
{
    public class UsuarioRepositorio : Repositorio<UsuarioDTO>,IUsuarioRepositorio
    {
        public UsuarioRepositorio(string connectionString) : base(connectionString)
        {
        }
        public async Task<IEnumerable<UsuarioDTO>> ObtenerUsuario()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryAsync<UsuarioDTO>("sp_obtener_Usuarios",
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> CrearUsuario(UsuarioDTO Usuario)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@usuario", Usuario.usuario);
            parametros.Add("@fk_id_cliente", Usuario.fkIdCliente);
            parametros.Add("@contrasena", Usuario.contrasena);
            parametros.Add("@estado", Usuario.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_crear_Usuario", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> ActualizarUsuario(UsuarioDTO Usuario)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_usuario", Usuario.idUsuario);
            parametros.Add("@usuario", Usuario.usuario);
            parametros.Add("@fk_id_cliente", Usuario.fkIdCliente);
            parametros.Add("@contrasena", Usuario.contrasena);
            parametros.Add("@estado", Usuario.estado);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_actualizar_Usuario", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> EliminarUsuario(UsuarioDTO Usuario)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_usuario", Usuario.idUsuario);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_eliminar_Usuario", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }
    }
}
