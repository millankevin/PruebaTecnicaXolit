﻿using Dapper;
using Dominio.DTO;
using Repositorio.Interfaz;
using System.Data.SqlClient;

namespace Repositorio.Implementacion
{
    public class ClienteRepositorio : Repositorio<ClienteDTO>, IClienteRepositorio
    {
        public ClienteRepositorio(string connectionString) : base(connectionString)
        {
        }

        public async Task<IEnumerable<ClienteDTO>> ObtenerCliente()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryAsync<ClienteDTO>("sp_obtener_clientes",
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> CrearCliente(ClienteDTO Cliente)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@identificacion", Cliente.identificacion);
            parametros.Add("@nombres", Cliente.nombre);
            parametros.Add("@apellidos", Cliente.apellido);
            parametros.Add("@celular", Cliente.telefono);
            parametros.Add("@direccion", Cliente.estado);
            parametros.Add("@email", Cliente.correoElectronico);
            parametros.Add("@idTipoCliente", Cliente.idTipoCliente);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_crear_cliente", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> ActualizarCliente(ClienteDTO Cliente)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_cliente", Cliente.idCliente);
            parametros.Add("@identificacion", Cliente.identificacion);
            parametros.Add("@nombres", Cliente.nombre);
            parametros.Add("@apellidos", Cliente.apellido);
            parametros.Add("@celular", Cliente.telefono);
            parametros.Add("@direccion", Cliente.estado);
            parametros.Add("@email", Cliente.correoElectronico);
            parametros.Add("@idTipoCliente", Cliente.idTipoCliente);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_actualizar_cliente", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }

        public async Task<int> EliminarCliente(ClienteDTO Cliente)
        {
            var parametros = new DynamicParameters();

            parametros.Add("@id_cliente", Cliente.idCliente);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var result = await connection.QueryFirstAsync<int>("sp_eliminar_cliente", parametros,
                    commandType: System.Data.CommandType.StoredProcedure);
                return result;
            }
        }
    }
}
