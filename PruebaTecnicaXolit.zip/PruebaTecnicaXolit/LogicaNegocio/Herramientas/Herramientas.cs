﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Herramientas
{
    public class Herramientas
    {
        public static bool TieneRegistros<T>(IEnumerable<T> listaElemntos)
        {
            //If ternario -> consultar es igual a un if pero mas simplificado
            return (listaElemntos != null && listaElemntos.Count() > 0) ? true : false;
        }
        public static bool DiferenteCero(int valor)
        {
            return (valor > 0) ? true : false;
        }
    }
}
