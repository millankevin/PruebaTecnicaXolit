﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Herramientas
{
    public class Respuestas
    {
        public static RespuestaDTO<T> RespuestaOkay<T>(T data)
        {
            return new RespuestaDTO<T>() { CodigoStatus = System.Net.HttpStatusCode.OK, Data = data };
        }

        public static RespuestaDTO<T> RespuestaSinRegistros<T>(string mensaje)
        {
            return new RespuestaDTO<T>() { CodigoStatus = System.Net.HttpStatusCode.NotFound, Mensaje = mensaje };
        }

        public static RespuestaDTO<T> RespuestaError<T>(string mensaje)
        {
            return new RespuestaDTO<T>() { CodigoStatus = System.Net.HttpStatusCode.BadRequest, Mensaje = mensaje };
        }

        public static RespuestaDTO<T> RespuestaErrores<T>(IEnumerable<string> errores)
        {
            return new RespuestaDTO<T>() { CodigoStatus = System.Net.HttpStatusCode.BadRequest, Errores = errores.ToList() };
        }
    }
}
