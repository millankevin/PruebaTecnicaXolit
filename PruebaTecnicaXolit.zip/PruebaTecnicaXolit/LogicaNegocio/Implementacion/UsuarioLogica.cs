﻿using Dominio.DTO;
using LogicaNegocio.Herramientas;
using LogicaNegocio.Interfaz;
using UnidadTrabajo.Interfaz;

namespace LogicaNegocio.Implementacion
{
    public class UsuarioLogica :IUsuarioLogica
    {
        private readonly IUnidadTrabajo _unidad;
        public UsuarioLogica(IUnidadTrabajo unidad)
        {
            _unidad = unidad;
        }
        public async Task<RespuestaDTO<IEnumerable<UsuarioDTO>>> ObtenerUsuario()
        {
            IEnumerable<UsuarioDTO> Usuario = await this._unidad.Usuario.ObtenerUsuario();
            return Herramientas.Herramientas.TieneRegistros(Usuario) ? Respuestas.RespuestaOkay(Usuario) :
                Respuestas.RespuestaSinRegistros<IEnumerable<UsuarioDTO>>("No se pudo obtener Usuario.");
        }
        public async Task<RespuestaDTO<string>> CrearUsuario(UsuarioDTO Usuario)
        {
            string mensaje = "Se creo exitosamente el usuario.";
            Usuario.contrasena = Encriptar.EncriptarString(Usuario.contrasena, Usuario.usuario);
            int IdUsuario = await this._unidad.Usuario.CrearUsuario(Usuario);
            return Herramientas.Herramientas.DiferenteCero(IdUsuario) ?
                Respuestas.RespuestaOkay($"{mensaje} {IdUsuario}") :
                Respuestas.RespuestaError<string>("No se pudo crear usuario.");
        }
        public async Task<RespuestaDTO<string>> ActualizarUsuario(UsuarioDTO Usuario)
        {
            string mensaje = "Se actualizo exitosamente el usuario ";
            Usuario.contrasena = Encriptar.EncriptarString(Usuario.contrasena, Usuario.usuario);
            int IdUsuario = await this._unidad.Usuario.ActualizarUsuario(Usuario);
            return Herramientas.Herramientas.DiferenteCero(IdUsuario) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo actualizar usuario.");
        }
        public async Task<RespuestaDTO<string>> EliminarUsuario(UsuarioDTO Usuario)
        {
            string mensaje = "Se elimino exitosamente el usuario ";
            int IdUsuario = await this._unidad.Usuario.EliminarUsuario(Usuario);
            return Herramientas.Herramientas.DiferenteCero(IdUsuario) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo eliminar usuario.");
        }
    }
}
