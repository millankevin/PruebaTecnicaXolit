﻿using Dominio.DTO;
using LogicaNegocio.Herramientas;
using LogicaNegocio.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnidadTrabajo.Interfaz;

namespace LogicaNegocio.Implementacion
{
    public class CuentaLogica: ICuentaLogica
    {
        private readonly IUnidadTrabajo _unidad;
        public CuentaLogica(IUnidadTrabajo unidad)
        {
            _unidad = unidad;
        }
        public async Task<RespuestaDTO<IEnumerable<CuentaDTO>>> ObtenerCuenta()
        {
            IEnumerable<CuentaDTO> Cuenta = await this._unidad.Cuenta.ObtenerCuenta();
            return Herramientas.Herramientas.TieneRegistros(Cuenta) ? Respuestas.RespuestaOkay(Cuenta) :
                Respuestas.RespuestaSinRegistros<IEnumerable<CuentaDTO>>("No se pudo obtener cuenta.");
        }
        public async Task<RespuestaDTO<string>> CrearCuenta(CuentaDTO Cuenta)
        {
            string mensaje = "Se creo exitosamente el cuenta ";
            int IdCuenta = await this._unidad.Cuenta.CrearCuenta(Cuenta);
            return Herramientas.Herramientas.DiferenteCero(IdCuenta) ?
                Respuestas.RespuestaOkay($"{mensaje} {IdCuenta}") :
                Respuestas.RespuestaError<string>("No se pudo crear cuenta.");
        }
        public async Task<RespuestaDTO<string>> ActualizarCuenta(CuentaDTO Cuenta)
        {
            string mensaje = "Se actualizo exitosamente el cuenta ";
            int IdCuenta = await this._unidad.Cuenta.ActualizarCuenta(Cuenta);
            return Herramientas.Herramientas.DiferenteCero(IdCuenta) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo actualizar cuenta.");
        }
        public async Task<RespuestaDTO<string>> EliminarCuenta(CuentaDTO Cuenta)
        {
            string mensaje = "Se elimino exitosamente el cuenta ";
            int IdCuenta = await this._unidad.Cuenta.EliminarCuenta(Cuenta);
            return Herramientas.Herramientas.DiferenteCero(IdCuenta) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo eliminar cuenta.");
        }
    }
}
