﻿using Dominio.DTO;
using LogicaNegocio.Herramientas;
using LogicaNegocio.Interfaz;
using UnidadTrabajo.Interfaz;

namespace LogicaNegocio.Implementacion
{
    public class TransaccionLogica :ITransaccionLogica
    {
        private readonly IUnidadTrabajo _unidad;
        public TransaccionLogica(IUnidadTrabajo unidad)
        {
            _unidad = unidad;
        }
        public async Task<RespuestaDTO<IEnumerable<TransaccionDTO>>> ObtenerTransaccion()
        {
            IEnumerable<TransaccionDTO> Transaccion = await this._unidad.Transaccion.ObtenerTransaccion();
            return Herramientas.Herramientas.TieneRegistros(Transaccion) ? Respuestas.RespuestaOkay(Transaccion) :
                Respuestas.RespuestaSinRegistros<IEnumerable<TransaccionDTO>>("No se pudo obtener transaccion.");
        }
        public async Task<RespuestaDTO<string>> CrearTransaccion(TransaccionDTO Transaccion)
        {
            string mensaje = "Se creo exitosamente el transaccion.";
            int IdTransaccion = await this._unidad.Transaccion.CrearTransaccion(Transaccion);
            return Herramientas.Herramientas.DiferenteCero(IdTransaccion) ?
                Respuestas.RespuestaOkay($"{mensaje} {IdTransaccion}") :
                Respuestas.RespuestaError<string>("No se pudo crear transaccion.");
        }
        public async Task<RespuestaDTO<string>> ActualizarTransaccion(TransaccionDTO Transaccion)
        {
            string mensaje = "Se actualizo exitosamente el Transaccion ";
            int IdTransaccion = await this._unidad.Transaccion.ActualizarTransaccion(Transaccion);
            return Herramientas.Herramientas.DiferenteCero(IdTransaccion) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo actualizar transaccion.");
        }
        public async Task<RespuestaDTO<string>> EliminarTransaccion(TransaccionDTO Transaccion)
        {
            string mensaje = "Se elimino exitosamente el Transaccion ";
            int IdTransaccion = await this._unidad.Transaccion.EliminarTransaccion(Transaccion);
            return Herramientas.Herramientas.DiferenteCero(IdTransaccion) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo eliminar transaccion.");
        }
    }
}
