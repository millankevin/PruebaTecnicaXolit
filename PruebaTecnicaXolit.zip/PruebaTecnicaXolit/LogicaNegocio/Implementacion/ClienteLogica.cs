﻿using Dominio.DTO;
using LogicaNegocio.Herramientas;
using LogicaNegocio.Interfaz;
using UnidadTrabajo.Interfaz;

namespace LogicaNegocio.Implementacion
{
    public class ClienteLogica : IClienteLogica
    {
        private readonly IUnidadTrabajo _unidad;
        public ClienteLogica(IUnidadTrabajo unidad)
        {
            _unidad = unidad;
        }
        public async Task<RespuestaDTO<IEnumerable<ClienteDTO>>> ObtenerCliente()
        {
            IEnumerable<ClienteDTO> Cliente = await this._unidad.Cliente.ObtenerCliente();
            return Herramientas.Herramientas.TieneRegistros(Cliente) ? Respuestas.RespuestaOkay(Cliente) :
                Respuestas.RespuestaSinRegistros<IEnumerable<ClienteDTO>>("No se pudo obtener Cliente.");
        }
        public async Task<RespuestaDTO<string>> CrearCliente(ClienteDTO cliente)
        {
            string mensaje = "Se creo exitosamente el cliente ";
            int IdCliente = await this._unidad.Cliente.CrearCliente(cliente);
            return Herramientas.Herramientas.DiferenteCero(IdCliente) ?
                Respuestas.RespuestaOkay($"{mensaje} {IdCliente}") :
                Respuestas.RespuestaError<string>("No se pudo crear cliente.");
        }
        public async Task<RespuestaDTO<string>> ActualizarCliente(ClienteDTO cliente)
        {
            string mensaje = "Se actualizo exitosamente el cliente ";
            int IdCliente = await this._unidad.Cliente.ActualizarCliente(cliente);
            return Herramientas.Herramientas.DiferenteCero(IdCliente) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo actualizar cliente.");
        }
        public async Task<RespuestaDTO<string>> EliminarCliente(ClienteDTO cliente)
        {
            string mensaje = "Se elimino exitosamente el cliente ";
            int IdCliente = await this._unidad.Cliente.EliminarCliente(cliente);
            return Herramientas.Herramientas.DiferenteCero(IdCliente) ?
                Respuestas.RespuestaOkay($"{mensaje}") :
                Respuestas.RespuestaError<string>("No se pudo eliminar cliente.");
        }
    }
}
