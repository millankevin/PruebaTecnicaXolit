﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaz
{
    public interface IClienteLogica
    {
        Task<RespuestaDTO<IEnumerable<ClienteDTO>>> ObtenerCliente();
        Task<RespuestaDTO<string>> CrearCliente(ClienteDTO Cliente);
        Task<RespuestaDTO<string>> ActualizarCliente(ClienteDTO Cliente);
        Task<RespuestaDTO<string>> EliminarCliente(ClienteDTO Cliente);
    }
}
