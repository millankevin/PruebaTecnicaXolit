﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaz
{
    public interface ICuentaLogica
    {
        Task<RespuestaDTO<IEnumerable<CuentaDTO>>> ObtenerCuenta();
        Task<RespuestaDTO<string>> CrearCuenta(CuentaDTO Cuenta);
        Task<RespuestaDTO<string>> ActualizarCuenta(CuentaDTO Cuenta);
        Task<RespuestaDTO<string>> EliminarCuenta(CuentaDTO Cuenta);
    }
}
