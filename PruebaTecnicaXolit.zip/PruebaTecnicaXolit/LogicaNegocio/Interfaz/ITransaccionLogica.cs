﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaz
{
    public interface ITransaccionLogica
    {
        Task<RespuestaDTO<IEnumerable<TransaccionDTO>>> ObtenerTransaccion();
        Task<RespuestaDTO<string>> CrearTransaccion(TransaccionDTO Transaccion);
        Task<RespuestaDTO<string>> ActualizarTransaccion(TransaccionDTO Transaccion);
        Task<RespuestaDTO<string>> EliminarTransaccion(TransaccionDTO Transaccion);
    }
}
