﻿using Dominio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaz
{
    public interface IUsuarioLogica
    {
        Task<RespuestaDTO<IEnumerable<UsuarioDTO>>> ObtenerUsuario();
        Task<RespuestaDTO<string>> CrearUsuario(UsuarioDTO Usuario);
        Task<RespuestaDTO<string>> ActualizarUsuario(UsuarioDTO Usuario);
        Task<RespuestaDTO<string>> EliminarUsuario(UsuarioDTO Usuario);
    }
}
