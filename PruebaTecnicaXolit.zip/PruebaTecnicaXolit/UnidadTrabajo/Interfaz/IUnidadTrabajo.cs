﻿using Repositorio.Interfaz;

namespace UnidadTrabajo.Interfaz
{
    public interface IUnidadTrabajo
    {
        IUsuarioRepositorio Usuario { get; }
        IClienteRepositorio Cliente { get; }
        ITransaccionRepositorio Transaccion { get; }
        ICuentaRepositorio Cuenta { get; }
    }
}
