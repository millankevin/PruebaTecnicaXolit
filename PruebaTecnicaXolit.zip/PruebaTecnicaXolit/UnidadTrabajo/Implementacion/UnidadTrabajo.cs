﻿using Repositorio.Implementacion;
using Repositorio.Interfaz;
using UnidadTrabajo.Interfaz;

namespace UnidadTrabajo.Implemantacion
{
    public class UnidadTrabajo : IUnidadTrabajo
    {
        public UnidadTrabajo(string connectionString)
        {
            Usuario = new UsuarioRepositorio(connectionString);
            Cliente = new ClienteRepositorio(connectionString);
            Transaccion = new TransaccionRepositorio(connectionString);
            Cuenta = new CuentaRepositorio(connectionString);
        }
        public IUsuarioRepositorio Usuario { get; set; }
        public IClienteRepositorio Cliente { get; set; }
        public ITransaccionRepositorio Transaccion { get; set; }
        public ICuentaRepositorio Cuenta { get; set; }

    }
}
