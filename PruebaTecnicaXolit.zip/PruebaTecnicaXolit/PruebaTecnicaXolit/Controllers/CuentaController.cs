﻿using Dominio.DTO;
using LogicaNegocio.Interfaz;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PruebaTecnicaXolit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CuentaController : ControllerBase
    {
        public readonly ICuentaLogica _cuentaLogica;

        public CuentaController(ICuentaLogica CuentaLogica)
        {
            _cuentaLogica = CuentaLogica;
        }

        [HttpGet]
        [Route("Obtener-Cuenta")]
        public async Task<IActionResult> ObtenerCuenta()
        {
            return Ok(await _cuentaLogica.ObtenerCuenta());
        }

        [HttpPost]
        [Route("Crear-Cuenta")]
        public async Task<IActionResult> CrearCuenta([FromBody] CuentaDTO Cuenta)
        {
            return Ok(await _cuentaLogica.CrearCuenta(Cuenta));
        }

        [HttpPut]
        [Route("Actualizar-Cuenta")]
        public async Task<IActionResult> ActualizarCuenta(CuentaDTO Cuenta)
        {
            return Ok(await _cuentaLogica.ActualizarCuenta(Cuenta));
        }

        [HttpPut]
        [Route("Eliminar-Cuenta")]
        public async Task<IActionResult> EliminarCuenta(CuentaDTO Cuenta)
        {
            return Ok(await _cuentaLogica.EliminarCuenta(Cuenta));
        }
    }
}
