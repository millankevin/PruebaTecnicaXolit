﻿using Dominio.DTO;
using LogicaNegocio.Interfaz;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PruebaTecnicaXolit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransaccionController : ControllerBase
    {
        public readonly ITransaccionLogica _transaccionLogica;

        public TransaccionController(ITransaccionLogica TransaccionLogica)
        {
            _transaccionLogica = TransaccionLogica;
        }

        [HttpGet]
        [Route("Obtener-Transaccion")]
        public async Task<IActionResult> ObtenerTransaccion()
        {
            return Ok(await _transaccionLogica.ObtenerTransaccion());
        }

        [HttpPost]
        [Route("Crear-Transaccion")]
        public async Task<IActionResult> CrearTransaccion([FromBody] TransaccionDTO Transaccion)
        {
            return Ok(await _transaccionLogica.CrearTransaccion(Transaccion));
        }

        [HttpPut]
        [Route("Actualizar-Transaccion")]
        public async Task<IActionResult> ActualizarTransaccion(TransaccionDTO Transaccion)
        {
            return Ok(await _transaccionLogica.ActualizarTransaccion(Transaccion));
        }

        [HttpPut]
        [Route("Eliminar-Transaccion")]
        public async Task<IActionResult> EliminarTransaccion(TransaccionDTO Transaccion)
        {
            return Ok(await _transaccionLogica.EliminarTransaccion(Transaccion));
        }
    }
}
