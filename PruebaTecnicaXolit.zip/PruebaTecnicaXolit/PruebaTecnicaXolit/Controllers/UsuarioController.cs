﻿using Dominio.DTO;
using LogicaNegocio.Interfaz;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PruebaTecnicaXolit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        public readonly IUsuarioLogica _usuarioLogica;

        public UsuarioController(IUsuarioLogica UsuarioLogica)
        {
            _usuarioLogica = UsuarioLogica;
        }

        [HttpGet]
        [Route("Obtener-Usuario")]
        public async Task<IActionResult> ObtenerUsuario()
        {
            return Ok(await _usuarioLogica.ObtenerUsuario());
        }

        [HttpPost]
        [Route("Crear-Usuario")]
        public async Task<IActionResult> CrearUsuario([FromBody] UsuarioDTO Usuario)
        {
            return Ok(await _usuarioLogica.CrearUsuario(Usuario));
        }

        [HttpPut]
        [Route("Actualizar-Usuario")]
        public async Task<IActionResult> ActualizarUsuario(UsuarioDTO Usuario)
        {
            return Ok(await _usuarioLogica.ActualizarUsuario(Usuario));
        }

        [HttpPut]
        [Route("Eliminar-Usuario")]
        public async Task<IActionResult> EliminarUsuario(UsuarioDTO Usuario)
        {
            return Ok(await _usuarioLogica.EliminarUsuario(Usuario));
        }
    }
}
