﻿using Dominio.DTO;
using LogicaNegocio.Interfaz;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PruebaTecnicaXolit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        public readonly IClienteLogica _clienteLogica;

        public ClienteController(IClienteLogica clienteLogica)
        {
            _clienteLogica = clienteLogica;
        }

        [HttpGet]
        [Route("Obtener-Cliente")]
        public async Task<IActionResult> ObtenerClientes()
        {
            return Ok(await _clienteLogica.ObtenerCliente());
        }

        [HttpPost]
        [Route("Crear-Cliente")]
        public async Task<IActionResult> CrearCliente([FromBody] ClienteDTO Cliente)
        {
            return Ok(await _clienteLogica.CrearCliente(Cliente));
        }

        [HttpPut]
        [Route("Actualizar-Cliente")]
        public async Task<IActionResult> ActualizarCliente(ClienteDTO Cliente)
        {
            return Ok(await _clienteLogica.ActualizarCliente(Cliente));
        }

        [HttpPut]
        [Route("Eliminar-Cliente")]
        public async Task<IActionResult> EliminarCliente(ClienteDTO Cliente)
        {
            return Ok(await _clienteLogica.EliminarCliente(Cliente));
        }
    }
}
