﻿using LogicaNegocio.Implementacion;
using LogicaNegocio.Interfaz;

namespace PruebaTecnicaXolit
{
    public static class Servicios
    {
        public static void Registrar(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<IUsuarioLogica, UsuarioLogica>();
            services.AddTransient<IClienteLogica, ClienteLogica>();
            services.AddTransient<ITransaccionLogica, TransaccionLogica>();
            services.AddTransient<ICuentaLogica, CuentaLogica>();
        }
    }
}
